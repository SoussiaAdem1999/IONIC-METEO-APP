import { Component, OnInit } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { debounceTime, distinctUntilChanged, switchMap } from 'rxjs/operators';
import { Subject } from 'rxjs';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
  imports: [CommonModule, FormsModule, IonicModule]  // Ensure these are included
})
export class HomePage implements OnInit {
  city: string = '';
  weatherData: any = null;
  loading: boolean = false;
  error: string = '';
  private searchSubject = new Subject<string>();


  private API_KEY = '91d4ba05694b4f1db95105505251405';
  private API_URL = 'https://api.weatherapi.com/v1/current.json';

  constructor(private http: HttpClient) {}

  ngOnInit() {
    this.setupSearch();
  }

  private setupSearch() {
    this.searchSubject.pipe(
      debounceTime(500),
      distinctUntilChanged(),
      switchMap(city => {
        if (city.trim().length > 2) {
          this.loading = true;
          this.error = '';
          return this.fetchWeatherData(city);
        } else {
          return [];
        }
      })
    ).subscribe({
      next: (data) => {
        this.weatherData = data;
        this.loading = false;
      },
      error: (err) => {
        this.error = 'Ville non trouvée. Essayez un autre nom.';
        this.loading = false;
        console.error(err);
      }
    });
  }

  searchCity() {
    this.searchSubject.next(this.city);
  }

  private fetchWeatherData(city: string) {
    const url = `${this.API_URL}?key=${this.API_KEY}&q=${encodeURIComponent(city)}`;
    return this.http.get(url);
  }

  // Fonction pour déterminer la classe d'animation en fonction des conditions météo
  getWeatherAnimationClass(condition: string): string {
    const conditionText = condition.toLowerCase();
    if (conditionText.includes('sunny') || conditionText.includes('clear')) {
      return 'weather-sunny';
    } else if (conditionText.includes('rain') || conditionText.includes('drizzle')) {
      return 'weather-rainy';
    } else if (conditionText.includes('cloud')) {
      return 'weather-cloudy';
    } else if (conditionText.includes('snow')) {
      return 'weather-snowy';
    } else {
      return 'weather-default';
    }
  }
}
